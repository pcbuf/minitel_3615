# example_annuaire.py corrigé — contenu corrigé à insérer ici
